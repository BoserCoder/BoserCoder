// Show the selected tab based on dropdown
function showTab(tab) {
    const tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(tabContent => tabContent.style.display = 'none');
    document.getElementById(tab).style.display = 'block';
  }
  
  // Show Basic Calculator by default
  window.onload = () => {
    showTab('calculator');
  };
  
  // Calculator functionality
  function appendToCalc(value) {
    const inputField = document.getElementById("calcInput");
    inputField.value += value;
  }
  
  function clearCalc() {
    const inputField = document.getElementById("calcInput");
    inputField.value = '';
  }
  
  function calculate() {
    const input = document.getElementById("calcInput").value;
    try {
      const result = eval(input);
      document.getElementById("calcResult").textContent = `Result: ${result}`;
    } catch {
      document.getElementById("calcResult").textContent = 'Invalid Equation';
    }
  }
  
  // Currency Converter
  function convertCurrency() {
    const amount = document.getElementById("currencyAmount").value;
    const from = document.getElementById("currencyFrom").value;
    const to = document.getElementById("currencyTo").value;
  
    if (!amount || isNaN(amount)) {
      document.getElementById("currencyResult").textContent = 'Please enter a valid amount.';
      return;
    }
  
    // Sample conversion rates (for demo purposes)
    const rates = {
      USD: { EUR: 0.91, INR: 82.21, GBP: 0.75 },
      EUR: { USD: 1.1, INR: 90.37, GBP: 0.82 },
      INR: { USD: 0.012, EUR: 0.011, GBP: 0.0095 },
      GBP: { USD: 1.33, EUR: 1.22, INR: 104.79 }
    };
  
    const converted = amount * rates[from][to];
    document.getElementById("currencyResult").textContent = `${amount} ${from} = ${converted.toFixed(2)} ${to}`;
  }
  
  // Temperature Converter
  function convertTemperature() {
    const temp = document.getElementById("tempInput").value;
    const fromUnit = document.getElementById("tempUnitFrom").value;
    const toUnit = document.getElementById("tempUnitTo").value;
  
    if (isNaN(temp)) {
      document.getElementById("tempResult").textContent = 'Please enter a valid temperature.';
      return;
    }
  
    let result;
    if (fromUnit === 'C' && toUnit === 'F') {
      result = (temp * 9/5) + 32;
    } else if (fromUnit === 'F' && toUnit === 'C') {
      result = (temp - 32) * 5/9;
    } else if (fromUnit === 'C' && toUnit === 'K') {
      result = parseFloat(temp) + 273.15;
    } else if (fromUnit === 'K' && toUnit === 'C') {
      result = temp - 273.15;
    } else if (fromUnit === 'F' && toUnit === 'K') {
      result = ((temp - 32) * 5/9) + 273.15;
    } else if (fromUnit === 'K' && toUnit === 'F') {
      result = ((temp - 273.15) * 9/5) + 32;
    } else {
      result = temp;
    }
  
    document.getElementById("tempResult").textContent = `Converted Temperature: ${result.toFixed(2)} ${toUnit}`;
  }
  
  // Time Converter (Simple Example)
  function convertTime() {
    const time = document.getElementById("timeInput").value;
    document.getElementById("timeResult").textContent = `Converted Time: ${time}`;
  }
  