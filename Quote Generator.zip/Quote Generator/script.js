// List of Motivational Quotes
const quotes = [
    "The only way to do great work is to love what you do. – Steve Jobs",
    "Believe you can and you're halfway there. – Theodore Roosevelt",
    "Success is not final, failure is not fatal: It is the courage to continue that counts. – Winston Churchill",
    "It always seems impossible until it's done. – Nelson Mandela",
    "You are never too old to set another goal or to dream a new dream. – C.S. Lewis",
    "The future belongs to those who believe in the beauty of their dreams. – Eleanor Roosevelt",
    "The best time to plant a tree was 20 years ago. The second best time is now. – Chinese Proverb",
    "Do not wait to strike till the iron is hot, but make it hot by striking. – William Butler Yeats",
    "Don’t watch the clock; do what it does. Keep going. – Sam Levenson",
    "Everything you can imagine is real. – Pablo Picasso"
  ];
  
  // Function to generate a random quote
  function generateQuote() {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    const quoteText = quotes[randomIndex];
  
    // Update the quote in the quote box
    document.getElementById('quote').innerText = quoteText;
  
    // Play the click sound (if sound is available)
    const clickSound = document.getElementById('clickSound');
    clickSound.play();
  }
  